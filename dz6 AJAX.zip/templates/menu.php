<a href="/">Главная</a>
<a href="/catalog">Каталог</a>
<a href="/gallery">Галерея</a>
<a href="/news">Новости</a>
<a href="/feedback">Отзывы</a>
<br>